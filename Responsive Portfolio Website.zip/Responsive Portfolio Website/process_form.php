<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Get form data
    $name = $_POST["name"];
    $email = $_POST["mail"];
    $phone = $_POST["mobile"];
    $city = $_POST["city"];
    $message = $_POST["message"];

    // Email details
    $to = "umairshaikh7738@gmail.com";
    $subject = "Contact Form Submission";
    $email_message = "Name: $name\n";
    $email_message .= "Email: $email\n";
    $email_message .= "Phone Number: $phone\n";
    $email_message .= "City: $city\n";
    $email_message .= "Message:\n$message\n";

    // Additional headers for CC option
    $headers = "From: $email\r\n";
    $headers .= "Cc: example@example.com\r\n"; // Add the CC email address here

    // Send the email
    $mail_sent = mail($to, $subject, $email_message, $headers);

    if ($mail_sent) {
        // Redirect to thank you page
        header("Location: thank_you_page.php");
        exit();
    } else {
        echo "Failed to send the email. Please try again later.";
    }
} else {
    // If someone tries to access this page directly without submitting the form, redirect to the form page.
    header("Location: contact_form.php");
    exit();
}
?>
