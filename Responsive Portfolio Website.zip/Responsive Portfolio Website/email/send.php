<?php
include_once './function.php';

$data = [
    'name' => 'Your Portfolio',
    'email' => 'umairshaikh7738@gmail.com'
];

$msgadminEMAIL = '';
foreach($_POST as $key => $val): //$_POST
    $msgadminEMAIL .= '<p><b>'.$key.'</b>: '.$val.'</p>';
endforeach;

// $to_email = 'umairshaikh7738@gmail.com, equityexchange72@gmail.com, info@equityexchangeacademy.in'; // Replace with the email addresses of the recipients
$to_email = 'umairshaikh7738@gmail.com'; // Replace with the email addresses of the recipients
//$cc_email = 'info@equityexchangeacademy.in';  Replace with the CC email address

try {
    send_email_using_smtp($msgadminEMAIL, 'Equity Exchange', $to_email, $data['name'], $cc_email);
} catch (Exception $e) {
    // Handle any exceptions or errors here
}

header('Location: /thank_you_page.php');
?>
