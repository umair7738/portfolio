<?php

function send_email_using_smtp($msg = null, $sub = null, $to = null, $to_name = null, $cc = null)
{
    // Sender and recipient details
    $from_email = 'umairshaikh7738@gmail.com';
    $from_name = 'Your Portfolio';
    $reply_to_email = $to;
    $reply_to_name = $to_name ? $to_name : '-';

    // SMTP server settings
    $smtp_host = 'smtp-relay.brevo.com';
    $smtp_port = 587;
    $smtp_username = 'umairshaikh7738@gmail.com';
    $smtp_password = 'jwURbvgC8n1TZONF';
    $smtp_security = 'tls'; // Use 'ssl' for most servers, or 'tls' for others

    // Email headers
    $headers = "From: $from_name <$from_email>\r\n";
    $headers .= "Reply-To: $reply_to_name <$reply_to_email>\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8\r\n";

    // Convert comma-separated CC email addresses to an array
    if ($cc) {
        $cc_emails = explode(',', $cc);
        foreach ($cc_emails as $cc_email) {
            $headers .= "Cc: $cc_email\r\n";
        }
    }

    try {
        // Send email using SMTP
        ini_set('SMTP', $smtp_host);
        ini_set('smtp_port', $smtp_port);
        ini_set('sendmail_from', $from_email);
        ini_set('sendmail_path', "/usr/sbin/sendmail -t -i");

        // To send HTML emails, you need to use the fourth parameter of mail() to pass headers
        mail($to, $sub, $msg, $headers, "-f$from_email");
    } catch (Exception $e) {
        // Handle any exceptions or errors here
    }
}
?>
