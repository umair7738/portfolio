<!DOCTYPE html>
<html>
<head>
  <title>Thank You!</title>
</head>
<body>
  <h2>Thank You for Contacting Us!</h2>
  <p>We will get back to you soon.</p>
</body>
</html>
